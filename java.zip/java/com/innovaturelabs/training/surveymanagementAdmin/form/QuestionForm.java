package com.innovaturelabs.training.surveymanagementAdmin.form;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

public class QuestionForm {
	
	private Integer surveyId;
	@Size(max = 30)
	@NotNull
	private String question;
	@Size(max = 30)
	private String questionType;
	
	public Integer getSurveyId() {
		return surveyId;
	}
	public void setSurveyId(Integer surveyId) {
		this.surveyId = surveyId;
	}
	public String getQuestion() {
		return question;
	}
	public void setQuestion(String question) {
		this.question = question;
	}
	public String getQuestionType() {
		return questionType;
	}
	public void setQuestionType(String questionType) {
		this.questionType = questionType;
	}
	
	
}
