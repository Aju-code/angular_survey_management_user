package com.innovaturelabs.training.surveymanagementAdmin.form;

import java.util.Collection;
import java.util.Date;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

import com.innovaturelabs.training.surveymanagementAdmin.json.Json;

public class SurveyForm {
	
    @Size(max = 30)
    @NotBlank
    private String surveyName;
    @Size(max = 30)
    private String description;
    @Json.DateFormat
    private Date startDate;
    @Json.DateFormat
    private Date endDate;
    
    public Collection<QuestionForm> getQuestions() {
		return questions;
	}
	public void setQuestions(Collection<QuestionForm> questions) {
		this.questions = questions;
	}
	private Collection<QuestionForm> questions;
    
	public String getSurveyName() {
		return surveyName;
	}
	public void setSurveyName(String surveyName) {
		this.surveyName = surveyName;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public Date getStartDate() {
		return startDate;
	}
	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}
	public Date getEndDate() {
		return endDate;
	}
	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}
    
    

}
