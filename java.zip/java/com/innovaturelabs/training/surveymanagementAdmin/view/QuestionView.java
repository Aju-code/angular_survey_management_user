package com.innovaturelabs.training.surveymanagementAdmin.view;

import com.innovaturelabs.training.surveymanagementAdmin.entity.Question;

public class QuestionView {
	private final int questionId;
	private final String question;
	private final String questonType;
	
	public QuestionView(Question question) {
		this.questionId = question.getQuestionId();
		this.question = question.getQuestion();
		this.questonType = question.getQuestionType();
	}
	public int getQuestionId() {
		return questionId;
	}
	public String getQuestion() {
		return question;
	}
	public String getQuestonType() {
		return questonType;
	}
	
}
