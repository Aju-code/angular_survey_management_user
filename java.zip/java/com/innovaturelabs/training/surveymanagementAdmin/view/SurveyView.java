package com.innovaturelabs.training.surveymanagementAdmin.view;

import java.util.Collection;
import java.util.Date;

import com.innovaturelabs.training.surveymanagementAdmin.entity.Survey;

public class SurveyView {
	
	private final int surveyId;
	private final String surveyName;
	private final String description;
	private final Date startDate;
	private final Date endDate;
	private final byte status;

	
	public SurveyView(Survey survey) {
		this.surveyId = survey.getSurveyId();
		this.surveyName = survey.getSurveyName();
		this.description = survey.getDescription();
		this.startDate = survey.getStartDate();
		this.endDate = survey.getEndDate();
		this.status=survey.getStatus();
	}


	public byte getStatus() {
		return status;
	}



	public SurveyView(int surveyId,String surveyName,String description,Date startDate,Date endDate,byte status) {
    	this.surveyId=surveyId;
    	this.surveyName=surveyName;
    	this.description=description;
    	this.startDate=startDate;
    	this.endDate=endDate;
    	this.status=status;
    }



	public int getSurveyId() {
		return surveyId;
	}

	public String getSurveyName() {
		return surveyName;
	}

	public String getDescription() {
		return description;
	}

	public Date getStartDate() {
		return startDate;
	}

	public Date getEndDate() {
		return endDate;
	}
	
	
 
}
