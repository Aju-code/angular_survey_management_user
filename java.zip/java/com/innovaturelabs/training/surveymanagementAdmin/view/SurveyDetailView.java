package com.innovaturelabs.training.surveymanagementAdmin.view;

import com.innovaturelabs.training.surveymanagementAdmin.entity.Survey;

public class SurveyDetailView extends SurveyView{
	
//	private final Collection<String> question;
	
	public SurveyDetailView(Survey survey) {
		super(
				survey.getSurveyId(),
				survey.getSurveyName(),
				survey.getDescription(),
				survey.getStartDate(),
				survey.getEndDate(),
		survey.getStatus());

		
	}

}