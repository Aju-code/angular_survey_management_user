package com.innovaturelabs.training.surveymanagementAdmin.repository;
import java.util.Collection;
import java.util.Optional;

import org.springframework.data.repository.Repository;

import com.innovaturelabs.training.surveymanagementAdmin.entity.Question;
import com.innovaturelabs.training.surveymanagementAdmin.view.QuestionView;


public interface QuestionRepository extends Repository<Question, Integer>{
	Question save(Question question);
	
	Collection<QuestionView> findAll();
	
	Collection<Question> findAllBySurveySurveyId(Integer surveyId);
	

	
}
