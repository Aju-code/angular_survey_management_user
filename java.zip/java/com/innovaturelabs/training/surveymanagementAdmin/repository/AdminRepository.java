/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.innovaturelabs.training.surveymanagementAdmin.repository;

import java.util.Collection;
import java.util.Optional;
import org.springframework.data.repository.Repository;

import com.innovaturelabs.training.surveymanagementAdmin.entity.Admin;
import com.innovaturelabs.training.surveymanagementAdmin.entity.Contact;

/**
 *
 * @author nirmal
 */
public interface AdminRepository extends Repository<Admin, Integer> {

    Optional<Admin> findById(Integer adminId);

    Optional<Admin> findByAdminIdAndPassword(Integer adminId, String password);

    Optional<Admin> findByEmail(String email);

    Admin save(Admin admin);
    
    Collection<Admin> findAll();
   

	void deleteById(Integer adminId);



}
