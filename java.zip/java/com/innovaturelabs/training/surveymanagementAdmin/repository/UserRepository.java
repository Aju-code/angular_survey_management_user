package com.innovaturelabs.training.surveymanagementAdmin.repository;

import java.util.Collection;
import java.util.Optional;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.Repository;

import com.innovaturelabs.training.surveymanagementAdmin.entity.User;


public interface UserRepository extends Repository<User, Integer>{
	
	@Query(value = "SELECT * FROM user where status!=0", nativeQuery = true)
	Collection<User> findByStatus(byte status);
	


	void deleteById(Integer userId);
	
	User save(User user);
	
	Optional<User> findById(Integer userId);
	

}
