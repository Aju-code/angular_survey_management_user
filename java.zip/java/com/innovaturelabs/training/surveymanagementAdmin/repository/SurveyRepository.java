package com.innovaturelabs.training.surveymanagementAdmin.repository;

import java.util.Collection;
import java.util.Optional;

import org.springframework.data.repository.Repository;

import com.innovaturelabs.training.surveymanagementAdmin.entity.Question;
import com.innovaturelabs.training.surveymanagementAdmin.entity.Survey;


public interface SurveyRepository extends Repository<Survey, Integer>{
	
	Survey save(Survey survey);
	
	Collection<Survey> findByStatus(byte status);
	
	Optional<Survey> findBySurveyIdAndAdminAdminId(Integer surveyId,Integer adminId);
	
	void deleteById(Integer surveyId);
	
	Optional<Survey> findById(Integer surveyId);
	
	
	
	
}
