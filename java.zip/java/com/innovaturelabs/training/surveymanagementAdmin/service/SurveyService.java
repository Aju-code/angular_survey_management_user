package com.innovaturelabs.training.surveymanagementAdmin.service;

import java.util.Collection;

import com.innovaturelabs.training.surveymanagementAdmin.entity.Question;
import com.innovaturelabs.training.surveymanagementAdmin.entity.Survey;
import com.innovaturelabs.training.surveymanagementAdmin.exception.NotFoundException;
import com.innovaturelabs.training.surveymanagementAdmin.form.SurveyForm;
import com.innovaturelabs.training.surveymanagementAdmin.view.ContactDetailView;
import com.innovaturelabs.training.surveymanagementAdmin.view.SurveyDetailView;
import com.innovaturelabs.training.surveymanagementAdmin.view.SurveyView;

public interface SurveyService {
	
	SurveyView add(SurveyForm form);
	
	Collection<Survey> surveyList();
	
	SurveyDetailView update(Integer surveyId,SurveyForm form) throws NotFoundException;
	
	
	void delete(Integer surveyId) throws NotFoundException;
	
	SurveyDetailView get(Integer surveyId) throws NotFoundException;
	

	
	

}
