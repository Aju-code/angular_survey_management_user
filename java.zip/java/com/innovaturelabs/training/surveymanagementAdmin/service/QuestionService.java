package com.innovaturelabs.training.surveymanagementAdmin.service;

import java.util.Collection;

import com.innovaturelabs.training.surveymanagementAdmin.entity.Question;
import com.innovaturelabs.training.surveymanagementAdmin.form.QuestionForm;
import com.innovaturelabs.training.surveymanagementAdmin.view.QuestionView;

public interface QuestionService {
	
	QuestionView add(QuestionForm form);
	
//	QuestionView get(Integer surveyId) throws NotFoundException;
	
	Collection<Question> list(Integer surveyId);
	
	
	
}
