/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.innovaturelabs.training.surveymanagementAdmin.service;

import java.util.Collection;

import org.springframework.validation.Errors;

import com.innovaturelabs.training.surveymanagementAdmin.entity.Admin;
import com.innovaturelabs.training.surveymanagementAdmin.entity.Survey;
import com.innovaturelabs.training.surveymanagementAdmin.entity.User;
import com.innovaturelabs.training.surveymanagementAdmin.exception.BadRequestException;
import com.innovaturelabs.training.surveymanagementAdmin.exception.NotFoundException;
import com.innovaturelabs.training.surveymanagementAdmin.form.AdminForm;
import com.innovaturelabs.training.surveymanagementAdmin.form.LoginForm;
import com.innovaturelabs.training.surveymanagementAdmin.view.AdminView;
import com.innovaturelabs.training.surveymanagementAdmin.view.LoginView;

/**
 *
 * @author nirmal
 */
public interface AdminService {

    AdminView add(AdminForm form);

    AdminView currentAdmin();

    LoginView login(LoginForm form, Errors errors) throws BadRequestException;

    LoginView refresh(String refreshToken) throws BadRequestException;

    Collection<Admin> list();
    
    Collection<User> lists();
    

//	void delete(Integer adminId)throws NotFoundException;
	
	void delete(Integer userId)throws NotFoundException;
	
	void block(Integer userId)throws NotFoundException;
	
	void unBlock(Integer userId)throws NotFoundException; 
	
}
