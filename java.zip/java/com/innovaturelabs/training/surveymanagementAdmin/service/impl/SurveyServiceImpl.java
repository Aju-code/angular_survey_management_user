package com.innovaturelabs.training.surveymanagementAdmin.service.impl;

import java.util.Collection;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.innovaturelabs.training.surveymanagementAdmin.entity.Question;
import com.innovaturelabs.training.surveymanagementAdmin.entity.Survey;
import com.innovaturelabs.training.surveymanagementAdmin.exception.NotFoundException;
import com.innovaturelabs.training.surveymanagementAdmin.form.QuestionForm;
import com.innovaturelabs.training.surveymanagementAdmin.form.SurveyForm;
import com.innovaturelabs.training.surveymanagementAdmin.repository.QuestionRepository;
import com.innovaturelabs.training.surveymanagementAdmin.repository.SurveyRepository;
import com.innovaturelabs.training.surveymanagementAdmin.security.util.SecurityUtil;
import com.innovaturelabs.training.surveymanagementAdmin.service.SurveyService;
import com.innovaturelabs.training.surveymanagementAdmin.view.SurveyDetailView;
import com.innovaturelabs.training.surveymanagementAdmin.view.SurveyView;

@Service
public class SurveyServiceImpl implements SurveyService {

	@Autowired
	private SurveyRepository surveyRepository;

	@Autowired
	private QuestionRepository questionRepository;

	@Override
	public SurveyView add(SurveyForm form) {

		SurveyView surveyView = new SurveyView(surveyRepository.save(new Survey(form.getSurveyName(),
				form.getDescription(),SecurityUtil.getCurrentUserId(), form.getStartDate(), form.getEndDate())));

		for (QuestionForm questionForm : form.getQuestions()) {
			questionRepository.save(
					new Question(surveyView.getSurveyId(), questionForm.getQuestion(), questionForm.getQuestionType()));
		}

		return surveyView;
	}
	
	@Override
	public Collection<Survey> surveyList(){
		return surveyRepository.findByStatus(Survey.Status.ACTIVE.value);
	}
	
	
	
	
	@Override
	public SurveyDetailView get(Integer surveyId) throws NotFoundException{
		return surveyRepository.findBySurveyIdAndAdminAdminId(surveyId,SecurityUtil.getCurrentUserId())
				.map((survey)->{
					return new SurveyDetailView(survey);
				}).orElseThrow(NotFoundException::new);
	}
	
	
	@Override
    @Transactional
    public SurveyDetailView update(Integer surveyId, SurveyForm form) throws NotFoundException {
        return surveyRepository.findBySurveyIdAndAdminAdminId(surveyId, SecurityUtil.getCurrentUserId())
                .map((survey) -> {
                    return new SurveyDetailView(surveyRepository.save(survey.update(form)));
                }).orElseThrow(NotFoundException::new);
    }
	
	@Override
	@Transactional
	public void delete(Integer surveyId) throws NotFoundException{
		Survey survey=surveyRepository.findById(surveyId).orElseThrow(NotFoundException::new);
		survey.setStatus(Survey.Status.INACTIVE.value);
		surveyRepository.save(survey);
	}

}
