package com.innovaturelabs.training.surveymanagementAdmin.service.impl;

import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.innovaturelabs.training.surveymanagementAdmin.entity.Question;
import com.innovaturelabs.training.surveymanagementAdmin.exception.NotFoundException;
import com.innovaturelabs.training.surveymanagementAdmin.form.QuestionForm;
import com.innovaturelabs.training.surveymanagementAdmin.repository.QuestionRepository;
import com.innovaturelabs.training.surveymanagementAdmin.security.util.SecurityUtil;
import com.innovaturelabs.training.surveymanagementAdmin.service.QuestionService;
import com.innovaturelabs.training.surveymanagementAdmin.view.QuestionView;
import com.innovaturelabs.training.surveymanagementAdmin.view.SurveyDetailView;

@Service
public class QuestionServiceImpl implements QuestionService{

	@Autowired
	private QuestionRepository questionRepository;

	@Override
	public QuestionView add(QuestionForm form) {
		
		return new QuestionView(questionRepository.save(new Question(
				form.getSurveyId(),
				form.getQuestion(),
				form.getQuestionType()
				)));
	}
	
	@Override
	public Collection<Question> list(Integer surveyId){
		return questionRepository.findAllBySurveySurveyId(surveyId);
	}
	
	
//	@Override
//    public QuestionView get(Integer surveyId) throws NotFoundException {
//        return questionRepository.findBySurveyIdAndQuestionQusetionId(surveyId)
//                .map((question) -> {
//                    return new QuestionView(question);
//                }).orElseThrow(NotFoundException::new);
//    }
	
	

	
	
}
