/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.innovaturelabs.training.surveymanagementAdmin.service.impl;

import com.innovaturelabs.training.surveymanagementAdmin.entity.Contact;
import com.innovaturelabs.training.surveymanagementAdmin.exception.NotFoundException;
import com.innovaturelabs.training.surveymanagementAdmin.form.ContactForm;
import com.innovaturelabs.training.surveymanagementAdmin.repository.ContactRepository;
import com.innovaturelabs.training.surveymanagementAdmin.security.util.SecurityUtil;
import com.innovaturelabs.training.surveymanagementAdmin.service.ContactService;
import com.innovaturelabs.training.surveymanagementAdmin.view.ContactDetailView;
import com.innovaturelabs.training.surveymanagementAdmin.view.ContactListView;

import java.util.Collection;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 *
 * @author nirmal
 */
@Service
public class ContactServiceImpl implements ContactService {

    @Autowired
    private ContactRepository contactRepository;

    @Override
    public Collection<ContactListView> list() {
        return contactRepository.findAllByAdminAdminId(SecurityUtil.getCurrentUserId());
    }

    @Override
    public ContactDetailView add(ContactForm form) {
        return new ContactDetailView(contactRepository.save(new Contact(form, SecurityUtil.getCurrentUserId())));
    }

    @Override
    public ContactDetailView get(Integer contactId) throws NotFoundException {
        return contactRepository.findByContactIdAndAdminAdminId(contactId, SecurityUtil.getCurrentUserId())
                .map((contact) -> {
                    return new ContactDetailView(contact);
                }).orElseThrow(NotFoundException::new);
    }

    @Override
    @Transactional
    public ContactDetailView update(Integer contactId, ContactForm form) throws NotFoundException {
        return contactRepository.findByContactIdAndAdminAdminId(contactId, SecurityUtil.getCurrentUserId())
                .map((contact) -> {
                    return new ContactDetailView(contactRepository.save(contact.update(form)));
                }).orElseThrow(NotFoundException::new);
    }

    @Override
    @Transactional
    public void delete(Integer contactId) throws NotFoundException {
        contactRepository.delete(
                contactRepository.findByContactIdAndAdminAdminId(contactId, SecurityUtil.getCurrentUserId())
                        .orElseThrow(NotFoundException::new)
        );
    }
}
