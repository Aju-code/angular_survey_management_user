/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.innovaturelabs.training.surveymanagementAdmin.service.impl;

import static com.innovaturelabs.training.surveymanagementAdmin.security.AccessTokenAdminDetailsService.PURPOSE_ACCESS_TOKEN;

import java.util.Collection;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.validation.Errors;

import com.innovaturelabs.training.surveymanagementAdmin.entity.Admin;
import com.innovaturelabs.training.surveymanagementAdmin.entity.User;
import com.innovaturelabs.training.surveymanagementAdmin.exception.BadRequestException;
import com.innovaturelabs.training.surveymanagementAdmin.exception.NotFoundException;
import com.innovaturelabs.training.surveymanagementAdmin.form.AdminForm;
import com.innovaturelabs.training.surveymanagementAdmin.form.LoginForm;
import com.innovaturelabs.training.surveymanagementAdmin.repository.AdminRepository;
import com.innovaturelabs.training.surveymanagementAdmin.repository.ContactRepository;
import com.innovaturelabs.training.surveymanagementAdmin.repository.SurveyRepository;
import com.innovaturelabs.training.surveymanagementAdmin.repository.UserRepository;
import com.innovaturelabs.training.surveymanagementAdmin.security.config.SecurityConfig;
import com.innovaturelabs.training.surveymanagementAdmin.security.util.InvalidTokenException;
import com.innovaturelabs.training.surveymanagementAdmin.security.util.SecurityUtil;
import com.innovaturelabs.training.surveymanagementAdmin.security.util.TokenExpiredException;
import com.innovaturelabs.training.surveymanagementAdmin.security.util.TokenGenerator;
import com.innovaturelabs.training.surveymanagementAdmin.security.util.TokenGenerator.Status;
import com.innovaturelabs.training.surveymanagementAdmin.security.util.TokenGenerator.Token;
import com.innovaturelabs.training.surveymanagementAdmin.service.AdminService;
import com.innovaturelabs.training.surveymanagementAdmin.view.AdminView;
import com.innovaturelabs.training.surveymanagementAdmin.view.LoginView;

/**
 *
 * @author nirmal
 */
@Service
public class AdminServiceImpl implements AdminService {

    private static final String PURPOSE_REFRESH_TOKEN = "REFRESH_TOKEN";

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private AdminRepository adminRepository;

    @Autowired
    private TokenGenerator tokenGenerator;
    
    @Autowired
    private ContactRepository contactRepository;

    @Autowired
    private SecurityConfig securityConfig;
    
    @Autowired
    private UserRepository userRepository;
    
    @Autowired
    private SurveyRepository surveyRepository;

    @Override
    public AdminView add(AdminForm form) {
        return new AdminView(adminRepository.save(new Admin(
                form.getName(),
                form.getEmail(),
                passwordEncoder.encode(form.getPassword())
        )));
    }

    @Override
    public AdminView currentAdmin() {
        return new AdminView(
        		adminRepository.findById(SecurityUtil.getCurrentUserId()).orElseThrow(NotFoundException::new)
        );
    }

    @Override
    public LoginView login(LoginForm form, Errors errors) throws BadRequestException {
        if (errors.hasErrors()) {
            throw badRequestException();
        }
        Admin admin = adminRepository.findByEmail(form.getEmail()).orElseThrow(AdminServiceImpl::badRequestException);
        if (!passwordEncoder.matches(form.getPassword(), admin.getPassword())) {
            throw badRequestException();
        }

        String id = String.format("%010d", admin.getAdminId());
        Token accessToken = tokenGenerator.create(PURPOSE_ACCESS_TOKEN, id, securityConfig.getAccessTokenExpiry());
        Token refreshToken = tokenGenerator.create(PURPOSE_REFRESH_TOKEN, id + admin.getPassword(), securityConfig.getRefreshTokenExpiry());
        return new LoginView(admin, accessToken, refreshToken);
    }

    @Override
    public LoginView refresh(String refreshToken) throws BadRequestException {
        Status status;
        try {
            status = tokenGenerator.verify(PURPOSE_REFRESH_TOKEN, refreshToken);
        } catch (InvalidTokenException e) {
            throw new BadRequestException("Invalid token", e);
        } catch (TokenExpiredException e) {
            throw new BadRequestException("Token expired", e);
        }

        int adminId;
        try {
        	adminId = Integer.parseInt(status.data.substring(0, 10));
        } catch (NumberFormatException e) {
            throw new BadRequestException("Invalid token", e);
        }

        String password = status.data.substring(10);

        Admin user = adminRepository.findByAdminIdAndPassword(adminId, password).orElseThrow(AdminServiceImpl::badRequestException);

        String id = String.format("%010d", user.getAdminId());
        Token accessToken = tokenGenerator.create(PURPOSE_ACCESS_TOKEN, id, securityConfig.getAccessTokenExpiry());
        return new LoginView(
                user,
                new LoginView.TokenView(accessToken.value, accessToken.expiry),
                new LoginView.TokenView(refreshToken, status.expiry)
        );
    }
    
//    @Override
//    @Transactional
//    public void delete(Integer adminId) throws NotFoundException {	
//    	contactRepository.deleteByAdminAdminId(adminId);	
//    	adminRepository.deleteById(adminId);
//       
//    }

    private static BadRequestException badRequestException() {
        return new BadRequestException("Invalid credentials");
    }

    @Override
    public Collection<Admin> list() {
        return adminRepository.findAll();
    }

	@Override
	public Collection<User> lists() {
		return userRepository.findByStatus(User.Status.ACTIVE.value);
	}

	@Override
	@Transactional
	public void delete(Integer userId) throws NotFoundException {
		User user=userRepository.findById(userId).orElseThrow(NotFoundException::new);
		user.setStatus(User.Status.INACTIVE.value);
		userRepository.save(user);
	}
	
	@Override
	@Transactional
	public void block(Integer userId)throws NotFoundException{
		User user=userRepository.findById(userId).orElseThrow(NotFoundException::new);
		user.setStatus(User.Status.BLOCK.value);
		userRepository.save(user);
	}
	
	@Override
	@Transactional
	public void unBlock(Integer userId)throws NotFoundException{
		User user=userRepository.findById(userId).orElseThrow(NotFoundException::new);
		user.setStatus(User.Status.ACTIVE.value);
		userRepository.save(user);
	}
	
	
	
	
}
