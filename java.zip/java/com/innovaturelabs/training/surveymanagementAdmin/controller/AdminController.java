/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.innovaturelabs.training.surveymanagementAdmin.controller;

import java.util.Collection;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.innovaturelabs.training.surveymanagementAdmin.entity.Admin;
import com.innovaturelabs.training.surveymanagementAdmin.entity.User;
import com.innovaturelabs.training.surveymanagementAdmin.form.AdminForm;
import com.innovaturelabs.training.surveymanagementAdmin.service.AdminService;
import com.innovaturelabs.training.surveymanagementAdmin.view.AdminView;

/**
 *
 * @author nirmal
 */
@RestController
@RequestMapping("/admin")
public class AdminController {

    @Autowired
    private AdminService adminService;

    @PostMapping
    public AdminView add(@Valid @RequestBody AdminForm form) {
        return adminService.add(form);
    }

    @GetMapping
    public Collection<Admin> list() {
        return adminService.list();
    }

    
    @GetMapping("/user")
    public Collection<User> lists(){
    	return adminService.lists();
    }
    
    @PutMapping("/delete/{userId}")
    public void delete1(@PathVariable("userId") Integer userId) {
        adminService.delete(userId);
    }
    
    @PutMapping("/block/{userId}")
    	public void block(@PathVariable("userId") Integer userId) {
    		adminService.block(userId);
    	}
    
    @PutMapping("/unblock/{userId}")
	public void unBlock(@PathVariable("userId") Integer userId) {
		adminService.unBlock(userId);
	}
    
    
  
}
