package com.innovaturelabs.training.surveymanagementAdmin.controller;

import java.security.Principal;
import java.util.Collection;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.innovaturelabs.training.surveymanagementAdmin.entity.Question;
import com.innovaturelabs.training.surveymanagementAdmin.entity.Survey;
import com.innovaturelabs.training.surveymanagementAdmin.form.SurveyForm;
import com.innovaturelabs.training.surveymanagementAdmin.service.SurveyService;
import com.innovaturelabs.training.surveymanagementAdmin.view.ContactDetailView;
import com.innovaturelabs.training.surveymanagementAdmin.view.SurveyDetailView;
import com.innovaturelabs.training.surveymanagementAdmin.view.SurveyView;

@RestController
@RequestMapping("/survey")
public class SurveyController {
	
  @Autowired
  private SurveyService surveyService;
  
  @PostMapping
  public SurveyView add(@Valid @RequestBody SurveyForm form) {
	  return surveyService.add(form);
  }
  
  @GetMapping
  public Collection<Survey> surveyList(){
  	return surveyService.surveyList();
  }
  
  @GetMapping("/{surveyId}")
  public SurveyDetailView get(@PathVariable("surveyId") Integer surveyId) {
      return surveyService.get(surveyId);
  }
  
 
  
  
  @PutMapping("edit/{surveyId}")
  public SurveyDetailView update(
          @PathVariable("surveyId") Integer surveyId,
          @Valid @RequestBody SurveyForm form
  ) {
      return surveyService.update(surveyId, form);
  }
  
  @PutMapping("/{surveyId}")
  public void delete(@PathVariable("surveyId") Integer surveyId) {
	  surveyService.delete(surveyId);
  }
  
}
