package com.innovaturelabs.training.surveymanagementAdmin.entity;


import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

@Entity
public class Question {
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer questionId;
    @ManyToOne(optional = false, fetch = FetchType.EAGER)
    private Survey survey;
    private String question;
    private String questionType;
	public Integer getQuestionId() {
		return questionId;
	}
	
	public Question() {
		
	}
	
	
	public Question(Integer surveyId,String question, String questionType) {
		this.survey = new Survey(surveyId);
		this.question = question;
		this.questionType = questionType;
	}
	public void setQuestionId(Integer questionId) {
		this.questionId = questionId;
	}
	public Survey getSurvey() {
		return survey;
	}
	public void setSurvey(Survey survey) {
		this.survey = survey;
	}
	public String getQuestion() {
		return question;
	}
	public void setQuestion(String question) {
		this.question = question;
	}
	public String getQuestionType() {
		return questionType;
	}
	public void setQuestionType(String questionType) {
		this.questionType = questionType;
	}
    
    

}
