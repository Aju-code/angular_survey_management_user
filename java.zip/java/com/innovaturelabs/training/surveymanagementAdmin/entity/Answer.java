package com.innovaturelabs.training.surveymanagementAdmin.entity;


import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

@Entity
public class Answer {
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer answerId;
    @ManyToOne(optional = false, fetch = FetchType.EAGER)
    private Survey survey;
//    @ManyToOne(optional = false, fetch = FetchType.LAZY)
//    private Question question;
    @ManyToOne(optional = false, fetch = FetchType.EAGER)
    private User user;
	
	
	public void setAnswerId(Integer answerId) {
		this.answerId = answerId;
	}
	
	
	public Survey getSurvey() {
		return survey;
	}
	public void setSurvey(Survey survey) {
		this.survey = survey;
	}
//	public Question getQuestion() {
//		return question;
//	}
//	public void setQuestion(Question question) {
//		this.question = question;
//	}
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
    
    

}
